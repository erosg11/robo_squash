% Simscape Multibody Link
% Version 6.0 (R2018b) 24-May-2018

%   Copyright 2007-2018 The MathWorks, Inc.
